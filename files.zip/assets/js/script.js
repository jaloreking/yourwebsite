// Mobile Menu
document.querySelector('.menu-toggle').onclick = function() {
  document.querySelector('.nav-menu').classList.toggle('open');
};

// Hero Slider
(function() {
  const slides = document.querySelectorAll('.hero-slider .slides img');
  const dots = document.querySelectorAll('.hero-slider .slider-controls .dot');
  let idx = 0;
  function showSlide(i) {
    slides.forEach((img,j)=>img.classList.toggle('active',i===j));
    dots.forEach((d,j)=>d.classList.toggle('active',i===j));
  }
  setInterval(function() {
    idx = (idx+1)%slides.length;
    showSlide(idx);
  }, 3500);
  dots.forEach((d,i)=>d.onclick=()=>showSlide(idx=i));
})();

// Testimonials Slider
(function() {
  const testimonials = document.querySelectorAll('.testimonial-slider .testimonial');
  const testDots = document.querySelectorAll('.testimonial-slider .test-dot');
  let tIdx = 0;
  function showT(i) {
    testimonials.forEach((t,j)=>t.classList.toggle('active',i===j));
    testDots.forEach((d,j)=>d.classList.toggle('active',i===j));
  }
  setInterval(function() {
    tIdx = (tIdx+1)%testimonials.length;
    showT(tIdx);
  }, 4200);
  testDots.forEach((d,i)=>d.onclick=()=>showT(tIdx=i));
})();

// Product Filter & Search
(function() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const prodCards = document.querySelectorAll('.products-grid .card');
  const searchBar = document.getElementById('searchBar');
  if(!prodCards.length){return;}
  let filter = 'all';
  filterBtns.forEach(btn=>
    btn.onclick=()=>{
      filterBtns.forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      filter = btn.getAttribute('data-filter');
      update();
    });
  if(searchBar){
    searchBar.addEventListener('input',update);
  }
  function update() {
    const searchVal = searchBar && searchBar.value.toLowerCase();
    prodCards.forEach(card => {
      const cat = card.getAttribute('data-category');
      const title = card.querySelector('h2').textContent.toLowerCase();
      const show = (filter==='all'||cat===filter)&&(title.includes(searchVal || '')||!searchVal);
      card.style.display = show ? 'flex':'none';
    });
  }
  update();
})();