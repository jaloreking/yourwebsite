// Navbar mobile menu
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".menu-toggle");
  const navLinks = document.querySelector(".nav-links");
  if (toggle) {
    toggle.onclick = () => navLinks.classList.toggle("show");
  }

  // Homepage slider
  const sliderImgs = [
    "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=900&q=80",
    "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=900&q=80"
  ];
  let idx = 0;
  const slider = document.getElementById("heroSliderImg");
  const dots = document.querySelectorAll(".slider-dot");
  if (slider) {
    setInterval(() => {
      idx = (idx + 1) % sliderImgs.length;
      slider.src = sliderImgs[idx];
      document.querySelectorAll(".slider-dot").forEach((dot,i)=>dot.classList.toggle("active",i==idx));
    }, 3600);
    dots.forEach((dot, i) => dot.onclick = () => {
      idx = i;
      slider.src = sliderImgs[idx];
      dots.forEach((d,j)=>d.classList.toggle("active",j==idx));
    });
  }

  // Products: Filtering & Search
  if (document.getElementById("productsList")) {
    const filterBtns = document.querySelectorAll(".filter-btn");
    const products = document.querySelectorAll(".product-card");
    const searchInput = document.getElementById("searchInput");
    let cType = "all";
    filterBtns.forEach(btn => {
      btn.onclick = () => {
        cType = btn.dataset.category;
        filterBtns.forEach(b=>b.classList.remove("active"));
        btn.classList.add("active");
        filterProducts();
      };
    });
    searchInput && searchInput.addEventListener("input", filterProducts);
    function filterProducts() {
      const searchVal = (searchInput?.value || "").toLowerCase();
      products.forEach(card => {
        const pType = card.dataset.type;
        const title = card.querySelector("h2").textContent.toLowerCase();
        const show = 
          (cType == "all" || pType == cType) &&
          (title.includes(searchVal) || !searchVal);
        card.style.display = show ? "flex" : "none";
      });
    }
  }
});